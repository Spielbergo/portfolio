const folioData = [
    {
        github : "https://github.com/Spielbergo/portfolio",
        slide1 : "https://www.scottsutherland.info/assets/images/folio/scottsutherland/portfolio-item-01.jpg",
        slide2 : "assets/images/folio/scottsutherland/portfolio-item-02.jpg",
        slide3 : "assets/images/folio/scottsutherland/portfolio-item-03.jpg",
        text1 : "test1",
        text2 : "data",
        text3 : "data"
    },
    {
        github : "https://github.com/Spielbergo/portfolio",
        slide1 : "https://www.scottsutherland.info/assets/images/folio/scottsutherland/portfolio-item-01.jpg",
        slide2 : "assets/images/folio/scottsutherland/portfolio-item-02.jpg",
        slide3 : "assets/images/folio/scottsutherland/portfolio-item-03.jpg",
        text1 : "data",
        text2 : "test2",
        text3 : "data"
    },
    {
        github : "https://github.com/Spielbergo/portfolio",
        slide1 : "https://www.scottsutherland.info/assets/images/folio/scottsutherland/portfolio-item-01.jpg",
        slide2 : "assets/images/folio/scottsutherland/portfolio-item-02.jpg",
        slide3 : "assets/images/folio/scottsutherland/portfolio-item-03.jpg",
        text1 : "data",
        text2 : "data",
        text3 : "test3"
    }
]
